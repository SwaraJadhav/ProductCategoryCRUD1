﻿namespace ProductCategoryCRUD.Models
{
    public class ProductcatgoryViewModel
    {
        public int? pid { get; set; }
        public int? cid { get; set; }
        public string? Pname { get; set; }
        public string? cname { get; set; }

    }
}
